package control;

import model.Result;

public class LoginController
{
    public Result login(String username, String password, boolean stayLoggedIn)
    {
        return null;
    }

    public Result forgetPassword(String username)
    {
        return null;
    }

    public Result answer(String answer)
    {
        return null;
    }
}