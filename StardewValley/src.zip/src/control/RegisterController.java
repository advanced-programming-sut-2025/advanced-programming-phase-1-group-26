package control;

import model.Result;

public class RegisterController
{
    public Result register(String username, String password, String passwordConfirm, String nickName, String email, String gender)
    {
        return null;
    }

    public Result pickQuestion(String questionNumber, String answer, String answerConfirm)
    {
        return null;
    }
}
