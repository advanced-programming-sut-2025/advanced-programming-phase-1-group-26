package control.game.activities;

import model.Result;

public class PlantsController
{
    public Result showCraftInfo(String craftName)
    {
        return null;
    }

    public Result plant(String seed, String direction)
    {
        return null;
    }

    public Result showPlant(String locationX, String locationY)
    {
        return null;
    }

    public Result fertilize(String fertilizer, String direction)
    {
        return null;
    }

    public Result howMuchWater()
    {
        return null;
    }
}
