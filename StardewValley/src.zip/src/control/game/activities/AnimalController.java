package control.game.activities;

public class AnimalController {
    public void build() {}

    public void tame() {}

    public void buy() {}

    public void sell() {}

    public void fishing() {}


}
