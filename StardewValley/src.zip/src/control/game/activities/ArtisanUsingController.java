package control.game.activities;

import model.Result;

public class ArtisanUsingController
{
    public Result artisanUse(String artisanName, String[] itemNames)
    {
        return null;
    }

    public Result artisanGet(String artisanName)
    {
        return null;
    }
}
