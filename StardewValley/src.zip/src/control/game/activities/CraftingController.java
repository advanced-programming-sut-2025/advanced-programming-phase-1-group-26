package control.game.activities;

import model.Result;

public class CraftingController
{
    public Result showRecipes()
    {
        return null;
    }

    public Result craftItem(String itemName)
    {
        return null;
    }

    public Result placeItem(String itemName, String direction)
    {
        return null;
    }

    public Result cheatAddItem(String itemName, String count)
    {
        return null;
    }
}
