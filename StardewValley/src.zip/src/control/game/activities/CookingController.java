package control.game.activities;

import model.Result;

public class CookingController
{
    public Result putItem(String itemName)
    {
        return null;
    }

    public Result pickItem(String itemName)
    {
        return null;
    }

    public Result showRecipes()
    {
        return null;
    }

    public Result prepare(String recipeName)
    {
        return null;
    }

    public Result eat(String foodName)
    {
        return null;
    }
}
