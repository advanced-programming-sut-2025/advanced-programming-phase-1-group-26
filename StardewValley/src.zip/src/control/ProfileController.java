package control;

import model.Result;

public class ProfileController
{
    public Result changeUsername(String newUsername)
    {
        return null;
    }

    public Result changeNickName(String newNickName)
    {
        return null;
    }

    public Result changeEmail(String newEmail)
    {
        return null;
    }

    public Result changePassword(String newPassword, String oldPassword)
    {
        return null;
    }

    public Result showUserInfo()
    {
        return null;
    }
}
