package control;

import model.Result;

public class MainMenuController
{
    public Result logout()
    {
        return null;
    }
}
