package model;

import java.util.ArrayList;

public class Map
{
    ArrayList<Farm> farms = new ArrayList<>();
    
}
