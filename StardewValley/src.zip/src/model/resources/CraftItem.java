package model.resources;

import model.enums.building_enums.CraftItemType;

public class CraftItem
{
    private final CraftItemType type;

    public CraftItem(CraftItemType type)
    {
        this.type = type;
    }
}
