package model.enums;

public enum GameObjectType
{

}
