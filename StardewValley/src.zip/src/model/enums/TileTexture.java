package model.enums;

public enum TileTexture
{
    DIRT,
    GRASS,
    LAKE,
    BUILDING;
}
