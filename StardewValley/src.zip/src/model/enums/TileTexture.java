package model.enums;

public enum TileTexture
{
    LAND,
    GRASS,
    LAKE,
    CABIN,
    GREEN_HOUSE,
    QUARRY;
}
