package model.enums.animal_enums;

public enum AnimalType {
}
