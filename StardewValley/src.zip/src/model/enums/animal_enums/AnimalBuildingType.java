package model.enums.animal_enums;

public enum AnimalBuildingType {
    BARN,
    COOP
}
