package model.enums;

public enum SkillType
{
    Farming,
    Mining,
    Gashtogozar,
    Fishing;
}
