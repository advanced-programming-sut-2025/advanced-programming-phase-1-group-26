package model.animal;

import model.enums.animal_enums.AnimalBuildingType;

public class AnimalBuilding {
    private AnimalBuildingType animalBuildingType;
    private int capacity;
    private int cost;
}
