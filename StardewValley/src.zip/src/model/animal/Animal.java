package model.animal;

import model.enums.animal_enums.AnimalType;

public class Animal {
    private AnimalType animalType;
    private int price;
    private boolean isFed;

    public void feed() {}
    public int getPrice()
    {
        return 0;
    }
}
