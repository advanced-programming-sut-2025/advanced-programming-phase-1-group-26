package model.tools;

import model.GameObject;
import model.enums.tool_enums.ToolType;

public abstract class Tool extends GameObject {
     ToolType type;
     String name;
}
