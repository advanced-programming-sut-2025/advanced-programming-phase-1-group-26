package model;

import model.enums.GameObjectType;

public class GameObject
{
    protected GameObjectType type;
}
