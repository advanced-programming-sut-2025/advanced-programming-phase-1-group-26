package view;

import java.util.Scanner;

public class AppView {
    public static void run(Scanner scanner){}
}
