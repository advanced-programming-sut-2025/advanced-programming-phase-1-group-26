package view;

import java.util.Scanner;

public class RegisterMenu implements AppMenu {
    LoginMenu loginMenu;
    @Override
    public void check(Scanner scanner) {

    }
}
