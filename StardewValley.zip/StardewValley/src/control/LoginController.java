package control;

public class LoginController {
    public void goToMainMenu(){}
}
