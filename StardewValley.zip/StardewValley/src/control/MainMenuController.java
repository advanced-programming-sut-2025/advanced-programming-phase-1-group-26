package control;

public class MainMenuController {
    public void goToProfileMenu(){}
    public void goToGameMenu(){}
}
