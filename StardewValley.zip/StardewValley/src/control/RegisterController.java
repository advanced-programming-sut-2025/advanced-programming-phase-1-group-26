package control;

public class RegisterController {
    public void goToLoginMenu(){}

}
