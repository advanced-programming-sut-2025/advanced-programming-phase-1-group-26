package model.Tools;

import model.GameObject;
import model.enums.ToolEnums.ToolType;

public abstract class Tool extends GameObject {
     ToolType type;
     String name;



}
