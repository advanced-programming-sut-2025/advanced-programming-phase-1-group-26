package model;

public class Tile
{
    int y;
    int x;

    public Tile(int y, int x)
    {
        this.y = y;
        this.x = x;
    }
}
