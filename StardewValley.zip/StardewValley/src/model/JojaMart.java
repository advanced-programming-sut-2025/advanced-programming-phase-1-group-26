package model;

import model.enums.*;

public class JojaMart extends Shop{
    PermanentShopItem permanentShopItem;
    SpringStock springStock;
    SummerStock summerStock;
    FallStock fallStock;
    WinterStock winterStock;
    @Override
    public void workabality(GameObjectType gameObjectType) {
    }
}
