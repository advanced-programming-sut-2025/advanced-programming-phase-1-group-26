package model;

import model.enums.GameObjectType;

public class PierresGeneralStore extends Shop{

    @Override
    public void workabality(GameObjectType gameObjectType) {
    }
}
